// Project Identifier: C0F4DFE8B340D81183C208F70F9D2D797908754D
//
//  project3.cpp
//  EECS281 Project 3
//
//  Created by Lydia Kim on 3/9/23.
//

#include "project3.hpp"
#include "TableEntry.h"
#include "xcode_redirect.hpp"
#include <getopt.h>
#include <vector>
#include <map>
#include <iostream>
#include <algorithm>
#include <unordered_map>

using namespace std;

struct lessFunctor {
    int colIndex;
    const TableEntry &a;
    
    lessFunctor(int colIndexIn, const TableEntry &a) : colIndex(colIndexIn), a(a) {}
    
    bool operator() (const vector<TableEntry> &row) const{
        return row[colIndex] < a;
    }
};

struct greaterFunctor {
    int colIndex;
    const TableEntry a;
    
    greaterFunctor(int colIndexIn, const TableEntry &a) : colIndex(colIndexIn), a(a) {}
    
    bool operator() (const vector<TableEntry> &row) const{
        return row[colIndex] > a;
    }
};

struct equalFunctor {
    int colIndex;
    const TableEntry a;
    
    equalFunctor(int colIndexIn, const TableEntry &a) : colIndex(colIndexIn), a(a) {}
    
    bool operator() (const vector<TableEntry> &row) const{
        return row[colIndex] == a;
    }
};

class Table {
public:
    string tablename;
    std::unordered_map<string, int> colName;
    vector<EntryType> colType;
    vector<vector<TableEntry>> data;
    std::map<TableEntry, vector<int>> bst;
    std::unordered_map<TableEntry, vector<int>> hash;
    
    int numRows = 0;
    int numCols = 0;
    bool bstGenerated = false;
    bool hashGenerated = false;
    string bstName;
    string hashName;
    int colIndex;
    
    void create(string name);
    void insert();
    void print(bool quiet);
    void deleteTable();
    void deleteHelper(TableEntry a, int index, char op);
    void printHelper(const TableEntry &a, int index, char op, vector<string>& tempColName, bool quiet);
    template<class Ftor>
    size_t printActual(Ftor functor, vector<string>& tempColName, bool quiet, size_t rowsPrinted);
    void generateBST();
    void generateHash();
    void regenerate();
    
};

class Database {
public:
    std::unordered_map<string, Table> map;
    
    void getMode(int argc, char *argv[]);
    void join(Table &first, Table &second);
    
    bool quiet = false;
};

void Database::getMode(int argc, char *argv[]) {
    opterr = false;
    int gotopt = 0;
    int option_index = 0;
    option long_opts[] ={
        { "quiet", no_argument, nullptr, 'q' },
        { "help", no_argument, nullptr, 'h' },
        { nullptr, 0, nullptr, '\0' },
    }; //long_options[]
    
    while((gotopt = getopt_long(argc, argv, "qh", long_opts, &option_index)) != -1) {
        switch (gotopt) {
            case 'q':
                quiet = true;
                break;
            case 'h':
                exit(0);
            default:
                cout << "Error: invalid option \n";
                exit(1);
        } //switch ..choice
    } //while
} //getMode

void Table::create(string name) {
    //check if the table already exists
    int colAmount;
    string columnType, columnName;
    cin >> colAmount;
    tablename = name;
    numCols = colAmount;
    //colName.resize(colAmount);
    colType.resize(colAmount);
    for (int i = 0; i < colAmount; ++i) {
        cin >> columnType;
        //double int bool string
        switch (columnType[0]) {
            case 'd':
                colType[i] = EntryType::Double;
                break;
            case 'i':
                colType[i] = EntryType::Int;
                break;
            case 'b':
                colType[i] = EntryType::Bool;
                break;
            case 's':
                colType[i] = EntryType::String;
                break;
                
            default:
                break;
        } //switch
    } //for loop
    
    cout << "New table " << name << " with column(s) ";
    for (int i = 0; i < colAmount; ++i) {
        cin >> columnName;
        colName.insert({columnName, i});
        cout << columnName << " ";
    }
    cout << "created\n";
    
} //create

void Table::insert() {
    string input, dataString;
    double dataDouble;
    int newRows, integer;
    bool dataBool;
    cin >> newRows >> input;
    data.reserve(numRows + newRows);
    for (int i = 0; i < newRows; ++i) {
        vector<TableEntry> oneD;
        for (int j = 0; j < numCols; ++j) {
            switch (colType[j]) {
                case EntryType::Double:
                    cin >> dataDouble;
                    oneD.emplace_back(dataDouble);
                    break;
                    
                case EntryType::Int:
                    cin >> integer;
                    oneD.emplace_back(integer);
                    break;
                    
                case EntryType::Bool:
                    cin >> dataBool;
                    oneD.emplace_back(dataBool);
                    break;
                    
                case EntryType::String:
                    cin >> dataString;
                    oneD.emplace_back(dataString);
                    break;
                    
                default:
                    break;
            } // switch
        } // loop cols
        data.emplace_back(oneD);
    } // loop rows
    cout << "Added " << newRows << " rows to " << tablename << " from position " << numRows << " to " << (numRows + newRows - 1) << "\n";
    numRows += newRows;
    
    regenerate();
} //insert

void Table::print(bool quiet) {
    int tempColAmount;
    string tempName;
    vector<string> tempColName;
    cin >> tempColAmount;
    tempColName.resize(tempColAmount);
    for (int i = 0; i < tempColAmount; ++i) {
        cin >> tempName;
        if (colName.find(tempName) == colName.end()) {
            cout << "Error during PRINT: " << tempName << " does not name a column in " << tablename << "\n";
            getline(cin, tempName);
            return;
        }
        tempColName[i] = tempName;
    } // loop col names
    cin >> tempName;
    if (tempName == "ALL") {
        if (!quiet) {
            //printing the name of the columns
            for (size_t i = 0; i < tempColName.size(); ++i) {
                cout << tempColName[i] << " ";
            }
            cout << "\n";
            
            for (int i = 0; i < numRows; ++i) {
                for (int j = 0; j < tempColAmount; ++j) {
                    int index = colName[tempColName[j]];
                    cout << data[i][index] << " ";
                }
                cout << "\n";
            } // loop rows
            
        } // not quiet
        cout << "Printed " << numRows << " matching rows from " << tablename << "\n";
    } //printing all
    
    else if (tempName == "WHERE") {
        string specCol, dataString;
        char op;
        double dataDouble;
        int dataInt, tempIndex;
        bool dataBool;
        cin >> specCol >> op;
        if (colName.find(specCol) == colName.end()) {
            cout << "Error during PRINT: " << specCol << " does not name a column in " << tablename << "\n";
            getline(cin, specCol);
            return;
        }
        
        if (!quiet) {
            for (size_t i = 0; i < tempColName.size(); ++i) {
                cout << tempColName[i] << " ";
            }
            cout << "\n";
        }
        
        tempIndex = colName[specCol];
        switch(colType[tempIndex]) {
            case EntryType::Double:
                cin >> dataDouble;
                printHelper(TableEntry(dataDouble), tempIndex, op, tempColName, quiet);
                break;
            case EntryType::Int:
                cin >> dataInt;
                printHelper(TableEntry(dataInt), tempIndex, op, tempColName, quiet);
                break;
            case EntryType::Bool:
                cin >> dataBool;
                printHelper(TableEntry(dataBool), tempIndex, op, tempColName, quiet);
                break;
            case EntryType::String:
                cin >> dataString;
                printHelper(TableEntry(dataString), tempIndex, op, tempColName, quiet);
                break;
                
            default:
                break;
        }
        
    } //print where

}

void Table::printHelper(const TableEntry &a, int index, char op, vector<string>& tempColName, bool quiet) {
    //three way split
    size_t rowsPrinted = 0;
    switch(op) {
        case '<':
            //check if columnIndex = index and bst == true
            if (colIndex == index && bstGenerated) {
                for (auto it = bst.begin(); it != bst.lower_bound(a); ++it) {
                    rowsPrinted += it->second.size();
                    if (!quiet) {
                        for (size_t i = 0; i < it->second.size(); ++i) {
                            for (string col: tempColName) {
                                cout << data[it->second[i]][colName[col]] << " ";
                            }
                            cout << "\n";
                        }
                    } //!quiet
                }
            } //if statement
            else {
                auto ftor = lessFunctor(index, a);
                rowsPrinted = printActual(ftor, tempColName, quiet, rowsPrinted);
            } //else statement
            
            break;
            
        case '>':
            //check if columnIndex = index and bst == true
            if (colIndex == index && bstGenerated) {
                for (auto it = bst.upper_bound(a); it != bst.end(); ++it) {
                    rowsPrinted += it->second.size();
                    if (!quiet) {
                        for (size_t i = 0; i < it->second.size(); ++i) {
                            for (string col: tempColName) {
                                cout << data[it->second[i]][colName[col]] << " ";
                            }
                            cout << "\n";
                        }
                    } //!quiet
                }
            }
            else {
                auto ftor = greaterFunctor(index, a);
                rowsPrinted = printActual(ftor, tempColName, quiet, rowsPrinted);
            }
            
            break;
            
        case '=':
            //check if columnIndex = index and bst == true || hash == true
            if (colIndex == index && (bstGenerated || hashGenerated)) {
                if (bstGenerated) {
                    for (auto it = bst.lower_bound(a); it != bst.upper_bound(a); ++it) {
                        rowsPrinted += it->second.size();
                        if (!quiet) {
                            for (size_t i = 0; i < it->second.size(); ++i) {
                                for (string col: tempColName) {
                                    cout << data[it->second[i]][colName[col]] << " ";
                                }
                                cout << "\n";
                            }
                        } //!quiet
                    }
                } //bstGenerated
                else { //hashGenerated
                    auto &vec = hash[a];
                    rowsPrinted += vec.size();
                    if (!quiet) {
                        for (auto row: vec) {
                            for (auto &item : tempColName) {
                                cout << data[row][colName[item]] << " ";
                            }
                            cout << "\n";
                        }
                    }
                } //hashGenerated
            } // bst or hash
            else {
                auto ftor = equalFunctor(index, a);
                rowsPrinted = printActual(ftor, tempColName, quiet, rowsPrinted);
            }
            break;
            
        default:
            break;
    } // switch
    
    cout << "Printed " << rowsPrinted << " matching rows from " << tablename << "\n";
    
}

template<class Ftor>
size_t Table::printActual(Ftor ftor, vector<string>& tempColName, bool quiet, size_t rowsPrinted) {
    for (size_t i = 0; i < data.size(); ++i) {
        if (ftor(data[i])) {
            ++rowsPrinted;
            if (!quiet) {
                for (string col : tempColName) {
                    cout << data[i][colName[col]] << " ";
                }
                cout << "\n";
            }
        }
    } //looping thru rows
    return rowsPrinted;
}

void Table::deleteTable() {
    string junk, tempColName, dataString;
    char op;
    int dataInt, tempIndex;
    bool dataBool;
    double dataDouble;
    cin >> junk >> tempColName;
    //take the size before

    //error checking
    if (colName.find(tempColName) == colName.end()) {
        cout << "Error during DELETE: " << tempColName << " does not name a column in " << tablename << "\n";
        getline(cin, tempColName);
        return;
    }
    cin >> op;
    tempIndex = colName[tempColName];
    switch (colType[tempIndex]) {
        case EntryType::Double:
            cin >> dataDouble;
            deleteHelper(TableEntry(dataDouble), tempIndex, op);
            break;
            
        case EntryType::Int:
            cin >> dataInt;
            deleteHelper(TableEntry(dataInt), tempIndex, op);
            break;
            
        case EntryType::Bool:
            cin >> dataBool;
            deleteHelper(TableEntry(dataBool), tempIndex, op);
            break;
            
        case EntryType::String:
            cin >> dataString;
            deleteHelper(TableEntry(dataString), tempIndex, op);
            break;
            
        default:
            break;
    } // switch case
    
    int newSize = (uint32_t)data.size();
    cout << "Deleted " << (numRows - newSize) << " rows from " << tablename << "\n";
    numRows = newSize;
    
    regenerate();
}


void Table::deleteHelper(TableEntry a, int index, char op) {
    //his value is my a
    switch(op) {
        case '<': {
            auto it = remove_if(data.begin(), data.end(), lessFunctor(index, a));
            data.erase(it, data.end());
            break;
        }
            
        case '>': {
            auto it1 = remove_if(data.begin(), data.end(), greaterFunctor(index, a));
            data.erase(it1, data.end());
            break;
        }
            
        case '=': {
            auto it2 = remove_if(data.begin(), data.end(), equalFunctor(index, a));
            data.erase(it2, data.end());
            break;
        }
    }
}

void Table::generateBST() {
    string columnName;
    cin >> columnName;
    if (colName.find(columnName) == colName.end()) {
        cout << "Error during GENERATE: " << columnName << " does not name a column in " << tablename << "\n";
        getline(cin, columnName);
        return;
    }
    bstGenerated = false;
    hashGenerated = false;
    bst.clear();
    hash.clear();
    auto it = colName.find(columnName);
    int temp = it->second;
    for (size_t i = 0; i < data.size(); ++i) {
        bst[data[i][temp]].emplace_back(i);
    }
    cout << "Created bst index for table " << tablename << " on column " << columnName << "\n";
    colIndex = temp;
    bstGenerated = true;
    bstName = columnName;
}

void Table::generateHash() {
    string columnName;
    cin >> columnName;
    if (colName.find(columnName) == colName.end()) {
        cout << "Error during GENERATE: " << columnName << " does not name a column in " << tablename << "\n";
        getline(cin, columnName);
        return;
    }
    bstGenerated = false;
    hashGenerated = false;
    hash.clear();
    bst.clear();
    auto it = colName.find(columnName);
    int temp = it->second;
    for (size_t i = 0; i < data.size(); ++i) {
        hash[data[i][temp]].emplace_back(i);
    }
    cout << "Created hash index for table " << tablename << " on column " << columnName << "\n";
    colIndex = temp;
    hashGenerated = true;
    hashName = columnName;
}

void Table::regenerate() {
    if (bstGenerated) {
        bst.clear();
        hash.clear();
        hashGenerated = false;
        for (size_t i = 0; i < data.size(); ++i) {
            bst[data[i][colIndex]].emplace_back(i);
        }
        bstGenerated = true;
    }
    else if (hashGenerated) {
        hash.clear();
        bst.clear();
        bstGenerated = false;
        for (size_t i = 0; i < data.size(); ++i) {
            hash[data[i][colIndex]].emplace_back(i);
        }
        hashGenerated = true;
    }
}

void Database::join(Table &first, Table &second) {
    string colname1, colname2, junk, printColName;
    int colAmount, tableNumber, tableOneIndex, tableTwoIndex;
    int rowsPrinted = 0;
    vector<int> printColNumber;
    vector<int> indexes;
    vector<string> printColNameVector;
    std::unordered_map<TableEntry, vector<int>> localHash;
    cin >> colname1 >> junk >> colname2; //"<colname1> = <colname2>"
    //TODO: the first column read in would be in the first table always?
    if (first.colName.find(colname1) == first.colName.end()) {
        cout << "Error during JOIN: " << colname1 << " does not name a column in " << first.tablename << "\n";
        getline(cin, colname1);
        return;
    }
    else {
        auto it = first.colName.find(colname1);
        tableOneIndex = it->second;
    }
    if (second.colName.find(colname2) == second.colName.end()) {
        cout << "Error during JOIN: " << colname2 << " does not name a column in " << second.tablename << "\n";
        getline(cin, colname2);
        return;
    }
    else {
        auto it = second.colName.find(colname2);
        tableTwoIndex = it->second;
    }
    
    cin >> junk >> junk >> colAmount; //"AND PRINT <N>"
    printColNumber.reserve(colAmount);
    printColNameVector.reserve(colAmount);
    indexes.reserve(colAmount);
    
    for (int i = 0; i < colAmount; ++i) {
        cin >> printColName >> tableNumber;
        if (tableNumber == 1) {
            if (first.colName.find(printColName) == first.colName.end()) {
                cout << "Error during JOIN: " << printColName << " does not name a column in " << first.tablename << "\n";
                getline(cin, printColName);
                return;
            }
            else {
                auto it = first.colName.find(printColName);
                int temp = it->second;
                indexes.emplace_back(temp);
            }
        } //if first table col
        else if (tableNumber == 2) {
            if (second.colName.find(printColName) == second.colName.end()) {
                cout << "Error during JOIN: " << printColName << " does not name a column in " << second.tablename << "\n";
                getline(cin, printColName);
                return;
            }
            else {
                auto it = second.colName.find(printColName);
                int temp = it->second;
                indexes.emplace_back(temp);
            }
        } //else if second table col
    
        printColNumber.emplace_back(tableNumber);
        printColNameVector.emplace_back(printColName);
    } //for loop
    
    //rehashing for the second table
    
    localHash.clear();
    for (size_t i = 0; i < second.data.size(); ++i) {
        localHash[second.data[i][tableTwoIndex]].emplace_back(i);
    }
    
    if (!quiet) {
        for (auto names : printColNameVector) {
            cout << names << " ";
        }
        cout << "\n";
    }
    
    for (size_t i = 0; i < first.data.size(); ++i) {
        for (auto it : localHash[first.data[i][tableOneIndex]]) {
            if (!quiet) {
                for (size_t j = 0; j < printColNumber.size(); ++j) {
                    if (printColNumber[j] == 1) {
                        cout << first.data[i][indexes[j]] << " ";
                    }
                    else {
                        cout << second.data[it][indexes[j]] << " ";
                    }
                }
                cout << "\n";
            }
            ++rowsPrinted;
        }
    }
    
    cout << "Printed " << rowsPrinted << " rows from joining " << first.tablename << " to " << second.tablename << "\n";
} //join


int main (int argc, char *argv[]) {
    ios_base::sync_with_stdio(false);
    xcode_redirect(argc, argv);
    cin >> std::boolalpha;
    cout << std::boolalpha;
    
    Database sillyQL;
    sillyQL.getMode(argc, argv);
    string command, tablename, junk, indexType, tablename2;
    
    do {
        cout << "% ";
        cin >> command;
        switch (command[0]) {
            case 'C':
                cin >> tablename;
                if (sillyQL.map.find(tablename) != sillyQL.map.end()) {
                    cout << "Error during CREATE: Cannot create already existing table " << tablename << "\n";
                    getline(cin, tablename);
                }
                else {
                    sillyQL.map[tablename].create(tablename);
                }
                break;
                
            case '#':
                getline(cin, command);
                break;
                
            case 'R':
                cin >> tablename;
                if (sillyQL.map.find(tablename) == sillyQL.map.end()) {
                    cout << "Error during REMOVE: " << tablename << " does not name a table in the database\n";
                    getline(cin, tablename);
                }
                else {
                    sillyQL.map.erase(tablename);
                    cout << "Table " << tablename << " deleted\n";
                }
                break;
                
            case 'I':
                cin >> junk >> tablename;
                if (sillyQL.map.find(tablename) == sillyQL.map.end()) {
                    cout << "Error during INSERT: " << tablename << " does not name a table in the database\n";
                    getline(cin, tablename);
                }
                else {
                    sillyQL.map[tablename].insert();
                }
                break;
                
            case 'P':
                cin >> junk >> tablename;
                if (sillyQL.map.find(tablename) == sillyQL.map.end()) {
                    cout << "Error during PRINT: " << tablename << " does not name a table in the database\n";
                    getline(cin, tablename);
                }
                else {
                    sillyQL.map[tablename].print(sillyQL.quiet);
                }
                break;
                
            case 'D':
                cin >> junk >> tablename;
                if (sillyQL.map.find(tablename) == sillyQL.map.end()) {
                    cout << "Error during DELETE: " << tablename << " does not name a table in the database\n";
                    getline(cin, tablename);
                }
                else {
                    sillyQL.map[tablename].deleteTable();
                }
                break;
            case 'J':
                cin >> tablename >> junk >> tablename2 >> junk;
                if (sillyQL.map.find(tablename) == sillyQL.map.end()) {
                    cout << "Error during JOIN: " << tablename << " does not name a table in the database\n";
                    getline(cin, tablename);
                }
                else if (sillyQL.map.find(tablename2) == sillyQL.map.end()) {
                    cout << "Error during JOIN: " << tablename2 << " does not name a table in the database\n";
                    getline(cin, tablename2);
                }
                else  {
                    sillyQL.join(sillyQL.map[tablename], sillyQL.map[tablename2]);
                }
                break;
            case 'G':
                cin >> junk >> tablename;
                if (sillyQL.map.find(tablename) == sillyQL.map.end()) {
                    cout << "Error during GENERATE: " << tablename << " does not name a table in the database\n";
                    getline(cin, tablename);
                }
                else {
                    cin >> indexType >> junk >> junk;
                    if (indexType == "hash") {
                        sillyQL.map[tablename].generateHash();
                    }
                    else if (indexType == "bst") {
                        sillyQL.map[tablename].generateBST();
                    }
                }
                break;
            case 'Q':
                cout << "Thanks for being silly!\n";
                break;
                
            default:
                cout << "Error: unrecognized command\n";
                getline(cin, junk);
                break;
        } //switch ..choice
    } while (command != "QUIT");
    
    return 0;
}
